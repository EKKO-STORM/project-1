A Pen created at CodePen.io. You can find this one at http://codepen.io/christianacca/pen/pJXybZ.

 Example of inline editing a single row in a table